# -*-coding:utf-8-*-
# @author: "旅行凯"
# @Time: 2021-12-10 8:25
# @File: 别踩白块.py

import pyautogui
import tkinter


top = tkinter.Tk()
top.wm_attributes('-topmost',1)
top.title('别踩白块了')
top.geometry('250x100')

'''bug主体'''
def white_bug():
    while True:
        rect = (0,0,1920,1080)
        get_photo = pyautogui.screenshot(region=rect)
        # get_photo.save("white.png")

        for i in range(500,805,100):
            for x in range(500,590,100):
                print(str(i) + "," + str(x))
        # 480,480,805,590
        # 325,110
                rgb_color = get_photo.getpixel((i,x))        #获取指定点的rgb值
                print(rgb_color)
                if rgb_color[0] == 2:
                    pyautogui.click(i, x)
                if rgb_color[1] == 237:
                    exit()
# 进入消息循环
b = tkinter.Button(top, text ="开始", command = white_bug)
b.pack()

c = tkinter.Label(top, text = "4399搜索：别踩白块了")
c.pack()

c = tkinter.Label(top, text = "----别踩白块----\nby:旅行凯")
c.pack()


top.mainloop()













